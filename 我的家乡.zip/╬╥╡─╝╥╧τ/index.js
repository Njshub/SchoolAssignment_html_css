document.addEventListener('DOMContentLoaded', function() {
    const cards = document.querySelectorAll('.card');
  
    cards.forEach(card => {
      card.addEventListener('click', () => {
        window.location.href = '#';
      });
    });
  });
  // index.js
document.addEventListener('scroll', function() {
    const sections = document.querySelectorAll('.bg-image-1, .bg-image-2, .bg-image-3');
    const scrollPosition = window.scrollY;
    sections.forEach(section => {
      const sectionTop = section.offsetTop;
      const sectionHeight = section.clientHeight;
      if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
        document.body.style.backgroundImage = section.style.backgroundImage;
      }
    });
  });
  document.addEventListener('scroll', function() {
    const sections = document.querySelectorAll('.section');
    const scrollPosition = window.scrollY + window.innerHeight / 2;

    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;

        if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
            document.body.style.backgroundImage = section.style.backgroundImage;
            const content = section.querySelector('.content');
            if (content) {
                content.classList.add('show');
            }
        }
    });
});
// index.js

// Function to check if an element is in the viewport
function isElementInViewport(el) {
    var rect = el.getBoundingClientRect();
    return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
}

// Function to add 'show' class to elements in the viewport
function showElementsInViewport() {
    var contents = document.querySelectorAll('.content');
    contents.forEach(function(content) {
        if (isElementInViewport(content)) {
            content.classList.add('show');
        }
    });
}

// Listen for scroll and resize events
window.addEventListener('scroll', showElementsInViewport);
window.addEventListener('resize', showElementsInViewport);

// Initial check when the page loads
document.addEventListener('DOMContentLoaded', function() {
    showElementsInViewport();
});
