document.addEventListener('DOMContentLoaded', function() {
    const carouselItems = document.querySelectorAll('.carousel-item');
    const totalItems = carouselItems.length;
    let currentIndex = 0;

    function showItem(index) {
        if (index < 0) {
            currentIndex = totalItems - 1;
        } else if (index >= totalItems) {
            currentIndex = 0;
        }

        carouselItems.forEach((item, idx) => {
            if (idx === currentIndex) {
                item.style.display = 'block';
            } else {
                item.style.display = 'none';
            }
        });
    }

    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');

    prevBtn.addEventListener('click', () => {
        currentIndex--;
        showItem(currentIndex);
    });

    nextBtn.addEventListener('click', () => {
        currentIndex++;
        showItem(currentIndex);
    });

    // Show the initial item
    showItem(currentIndex);
});
